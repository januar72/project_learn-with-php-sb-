
<?php
if (session_status() == PHP_SESSION_NONE) {
session_start();
}
include 'koneksi.php';

// Redirect to login if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle form submission to update user data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];

    // Insert or update user data
    $sql = "INSERT INTO user_data (user_id, full_name, email) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE full_name = VALUES(full_name), email = VALUES(email)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $user_id, $full_name, $email);
    $stmt->execute();
    echo "Data updated successfully!";
}

// Fetch user data
$sql = "SELECT * FROM user_data WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user_data = $result->fetch_assoc();
?>

<section class="content-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-lg-4">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Input Data</h3>
                    </div>
                    <div class="box-body" style="overflow: auto;">
                        <form method="post" action="">
                            <div class="form-group">
                                <label>Full Name</label>
                                <input type="text" name="full_name" required class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" required class="form-control">
                            </div>
                            <div class="box-footer">
                                <input type="submit" name="submit" class="btn btn-primary">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="box box-info">
                  <div class="box-header with-border">
                      <h3 class="box-title">Tabel Data</h3>
                  </div>  
                  <div class="box-body" style="overflow: auto;">
                      <table id="example1" class="table table-bordered table-striped">
                          <thead>
                              <tr>
                                  <th>No</th>
                                  <th>Nama</th>
                                  <th>Email</th>
                                  <th>Aksi</th>
                              </tr>
                          </thead>
                          <tbody>
                            <?php include 'koneksi.php';
                            $no=1; ?>
                              <tr>
                                  <td><?php echo $no++; ?></td>
                                  <td><?php echo htmlspecialchars(@$user_data['full_name']); ?></td>
                                  <td><?php echo htmlspecialchars(@$user_data['email']); ?> </td>
                                  <td><a href="hapus_data.php?id=<?php echo $user_data['id']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a></td>
                              </tr>
                          </tbody>
                      </table>
                  </div>
                </div>
            </div>
        </div>
    </div>
</section>

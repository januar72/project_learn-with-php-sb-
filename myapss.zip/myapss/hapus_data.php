<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus =mysqli_query($conn, "DELETE FROM user_data WHERE id='$id'");
var_dump($hapus);
die();
 ?>